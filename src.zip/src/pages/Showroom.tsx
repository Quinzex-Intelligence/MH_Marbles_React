import SEO from '@/components/SEO';
import { PageLayout } from '@/components/PageLayout';
import { motion } from 'framer-motion';

const Atelier = () => {
    return (
        <>
            <SEO 
                title="The Atelier: Art of Precision" 
                description="Experience the high-density craft of architectural stone carving. From master selection to diamond-jet precision geometry."
            />
            <PageLayout title="The Atelier." subtitle="The Craft of Precision">
            <section className="py-24 md:py-48 bg-background relative z-10 overflow-hidden">
                {/* Background Grid */}
                <div className="absolute inset-0 pointer-events-none z-0 opacity-20">
                    <div className="w-full h-full max-w-[1400px] mx-auto grid grid-cols-4 md:grid-cols-12 gap-4 px-4 md:px-[8%]">
                        {Array.from({ length: 12 }).map((_, i) => (
                            <div key={i} className="hidden md:block h-full border-r border-border/40" />
                        ))}
                    </div>
                </div>

                <div className="w-full max-w-none px-4 md:px-[8%] relative z-10">
                    
                    {/* Phase 01 */}
                    <div className="flex flex-col lg:flex-row gap-16 md:gap-32 items-center mb-32 md:mb-64">
                        <motion.div
                            initial={{ opacity: 0, x: -50 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ duration: 1.2, ease: "easeOut" }}
                            className="flex-1 lg:max-w-xl"
                        >
                            <div className="flex items-center gap-4 mb-8 md:mb-12">
                               <div className="w-12 h-[1px] bg-accent" />
                               <span className="text-[10px] font-sans font-bold text-accent tracking-[0.8em] uppercase">Phase 01</span>
                            </div>
                            
                            <h2 className="text-5xl sm:text-6xl md:text-8xl font-serif font-light text-foreground leading-[0.9] tracking-tighter mb-8 md:mb-12">
                                The <span className="italic">Selection.</span>
                            </h2>
                            <div className="space-y-8 text-base md:text-xl font-sans font-light text-foreground/70 leading-relaxed max-w-lg">
                                <p>
                                    Our master curators journey to the earth's deepest veins.
                                    Only 1 in 1,000 slabs meets the structural integrity and
                                    chromatic purity required for our signature collection.
                                </p>
                            </div>
                        </motion.div>
                        
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ duration: 1.5, ease: "easeOut" }}
                            className="flex-1 w-full"
                        >
                            <div className="aspect-[4/5] md:aspect-[3/4] bg-background/5 relative overflow-hidden ring-1 ring-white/10 group">
                                <img
                                    src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&q=80&w=1200"
                                    alt="Quarry Selection"
                                    className="w-full h-full object-cover grayscale-[40%] contrast-125 opacity-80 group-hover:scale-110 transition-transform duration-[3s] ease-out"
                                />
                                <div className="absolute inset-0 border-[1px] border-white/10 m-4 md:m-8 pointer-events-none" />
                            </div>
                        </motion.div>
                    </div>

                    {/* Phase 02 */}
                    <div className="flex flex-col lg:flex-row gap-16 md:gap-32 items-center mb-32 md:mb-48">
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            whileInView={{ opacity: 1, scale: 1 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ duration: 1.5, ease: "easeOut" }}
                            className="flex-1 w-full order-2 lg:order-1"
                        >
                            <div className="aspect-[4/5] md:aspect-[3/4] bg-background/5 relative overflow-hidden ring-1 ring-white/10 group">
                                <img
                                    src="https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?auto=format&fit=crop&q=80&w=1200"
                                    alt="Diamond Cutting"
                                    className="w-full h-full object-cover grayscale-[20%] contrast-125 opacity-80 group-hover:scale-110 transition-transform duration-[3s] ease-out"
                                />
                                <div className="absolute inset-0 border-[1px] border-white/10 m-4 md:m-8 pointer-events-none" />
                            </div>
                        </motion.div>
                        
                        <motion.div
                            initial={{ opacity: 0, x: 50 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ duration: 1.2, ease: "easeOut" }}
                            className="flex-1 lg:max-w-xl order-1 lg:order-2 lg:ml-auto"
                        >
                            <div className="flex items-center gap-4 mb-8 md:mb-12">
                               <div className="w-12 h-[1px] bg-accent" />
                               <span className="text-[10px] font-sans font-bold text-accent tracking-[0.8em] uppercase">Phase 02</span>
                            </div>
                            
                            <h2 className="text-5xl sm:text-6xl md:text-8xl font-serif font-light text-foreground leading-[0.9] tracking-tighter mb-8 md:mb-12">
                                The <span className="italic">Geometry.</span>
                            </h2>
                            <div className="space-y-8 text-base md:text-xl font-sans font-light text-foreground/70 leading-relaxed max-w-lg">
                                <p>
                                    Using water-jet precision and diamond-tipped mastery,
                                    we carve stone to within a fraction of a millimeter.
                                    Architecture is the profound science of the precise.
                                </p>
                            </div>
                        </motion.div>
                    </div>

                    {/* High-density Content / Metrics */}
                    <div className="pt-20 md:pt-32 border-t border-border/40">
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-12 md:gap-16">
                            {[
                                { val: "0.01mm", label: "Precision Margin" },
                                { val: "12 Stage", label: "Polishing Process" },
                                { val: "100%", label: "Sustainable Trace" },
                                { val: "45 Yrs", label: "Master Craft" }
                            ].map((stat, i) => (
                                <motion.div 
                                    key={i} 
                                    initial={{ opacity: 0, y: 20 }}
                                    whileInView={{ opacity: 1, y: 0 }}
                                    viewport={{ once: true, margin: "-50px" }}
                                    transition={{ duration: 0.8, delay: i * 0.1 }}
                                    className="text-left space-y-4"
                                >
                                    <div className="w-8 h-[1px] bg-accent/40 mb-6" />
                                    <p className="text-3xl md:text-5xl lg:text-6xl font-serif font-light italic text-accent opacity-90">{stat.val}</p>
                                    <p className="text-[9px] font-sans font-bold uppercase tracking-[0.4em] text-foreground/50">{stat.label}</p>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>
        </PageLayout>
        </>
    );
};

export default Atelier;
