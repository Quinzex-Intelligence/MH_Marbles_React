import React from 'react';
import SEO from '@/components/SEO';
import { useGallery } from '@/contexts/GalleryContext';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Droplets, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Sanitary = () => {
  const { sanitary } = useGallery();

  return (
    <>
      <SEO 
        title="Bath & Wellness: Luxury Sanitary Ware" 
        description="Explore our curated collection of world-class sanitary fixtures. Transform your private sanctuaries into masterpieces of design and engineering."
      />
      <div className="min-h-screen bg-[#050505] text-white selection:bg-accent/30 selection:text-white">
      <Header />
      
      <main className="pt-32 pb-40">
        <div className="container px-8">
          {/* Hero Section */}
          <div className="max-w-4xl mb-32">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="flex items-center gap-4 mb-8"
            >
              <div className="w-12 h-px bg-accent" />
              <span className="text-xs font-black uppercase tracking-[0.4em] text-accent">Bath & Wellness</span>
            </motion.div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-6xl md:text-8xl lg:text-9xl font-serif font-light leading-[0.9] tracking-tighter mb-12"
            >
              Sanitary <span className="italic text-white/25">Ware.</span>
            </motion.h1>
            
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-lg md:text-xl text-white/40 font-light max-w-2xl leading-relaxed"
            >
              Beyond utility. We curate world-class fixtures that transform private sanctuaries into masterpieces of design and engineering.
            </motion.p>
          </div>

          {/* Collection Grid */}
          {sanitary.length === 0 ? (
             <div className="py-40 text-center border border-white/5 bg-white/[0.01]">
                <Droplets className="w-10 h-10 text-white/10 mx-auto mb-6" />
                <p className="text-sm font-bold uppercase tracking-[0.3em] text-white/20">The current collection is being curated</p>
                <Link to="/contact" className="inline-flex items-center gap-2 mt-8 text-accent text-xs font-black uppercase tracking-widest hover:gap-4 transition-all">
                  Inquire for specialized sourcing <ArrowRight size={14} />
                </Link>
             </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-white/10 border border-white/10">
              {sanitary.map((item, index) => (
                <motion.div 
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="group bg-[#050505] p-12 md:p-20 relative overflow-hidden"
                >
                  <div className="aspect-[4/5] overflow-hidden bg-white/5 mb-12">
                    <img 
                      src={item.image} 
                      alt={item.name} 
                      className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-1000 group-hover:scale-110"
                    />
                  </div>
                  
                  <div className="relative z-10">
                    <div className="flex justify-between items-end mb-6">
                      <h3 className="text-3xl md:text-4xl font-serif font-light italic text-white group-hover:text-accent transition-colors duration-500">
                        {item.name}
                      </h3>
                      {item.price && (
                        <span className="text-xs font-black text-accent tracking-widest">{item.price}</span>
                      )}
                    </div>
                    
                    <p className="text-sm text-white/40 leading-relaxed max-w-lg mb-12 uppercase tracking-widest font-sans">
                      {item.description}
                    </p>
                    
                    <Link 
                      to="/contact" 
                      className="inline-flex items-center gap-3 text-[10px] font-black uppercase tracking-[0.3em] text-white group-hover:text-accent transition-colors duration-500"
                    >
                      Acquire This Piece <ArrowRight size={14} className="group-hover:translate-x-2 transition-transform duration-500" />
                    </Link>
                  </div>
                  
                  {/* Decorative number */}
                  <span className="absolute bottom-12 right-12 text-8xl font-serif italic text-white/[0.02] pointer-events-none">
                    0{index + 1}
                  </span>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
    </>
  );
};

export default Sanitary;
