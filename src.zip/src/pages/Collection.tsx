import SEO from '@/components/SEO';
import { PageLayout } from '@/components/PageLayout';
import { ProductCollection } from '@/components/ProductCollection';

const CurationPage = () => {
    return (
        <>
            <SEO 
                title="Signature Architectural Collection" 
                description="Discover our hand-picked selection of the world's most exquisite architectural stones. From Carrara marble to exotic finish tiles."
            />
            <PageLayout
            title="The Curation."
            subtitle="Architectural Series"
        >
            <div className="space-y-16 md:space-y-32">
                <ProductCollection />
                
                <section className="bg-foreground text-background py-24 md:py-40 relative overflow-hidden group">
                    <div className="absolute inset-0 opacity-10 blur-xl group-hover:blur-3xl transition-all duration-[3s] bg-accent mix-blend-screen scale-150 rounded-full w-1/2 h-1/2 -top-1/4 -right-1/4" />
                    
                    <div className="w-full max-w-none px-4 md:px-[8%] relative z-10 text-center">
                        <span className="text-[10px] font-sans font-bold tracking-[0.8em] uppercase text-accent mb-10 block">Exclusive Access</span>
                        <h3 className="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-serif font-light leading-[0.9] tracking-tighter mb-8 md:mb-12">
                            The Architect's <br />
                            <span className="italic text-muted-foreground/80">Reserve.</span>
                        </h3>
                        <p className="text-base md:text-2xl font-sans font-light text-background/60 max-w-2xl mx-auto leading-relaxed mb-16">
                            Our bespoke curation spans across the most prestigious quarries of the world.
                            Register your interest for private viewings of these limited edition natural masterpieces.
                        </p>
                        
                        <a href="/concierge" className="inline-flex items-center justify-center border border-accent hover:bg-accent hover:text-white h-16 px-12 text-[10px] font-sans font-bold uppercase tracking-[0.5em] transition-all duration-700">
                            Apply for Access
                        </a>
                    </div>
                </section>
            </div>
        </PageLayout>
        </>
    );
};

export default CurationPage;
