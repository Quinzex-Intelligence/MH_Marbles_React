import SEO from '@/components/SEO';
import { PageLayout } from '@/components/PageLayout';
import { motion } from 'framer-motion';
import { Cpu, Eye, Zap, ShieldCheck } from 'lucide-react';

const OurProcess = () => {
    return (
        <>
            <SEO 
                title="Our Process: Precision & Technology" 
                description="Experience the journey from digital twin mapping to structural analysis. We combine traditional craftsmanship with visionary technology."
            />
            <PageLayout title="Our Process." subtitle="Quality & Precision">
            <section className="py-24 md:py-48 bg-background relative z-10 overflow-hidden">
                {/* Background Architectural Grid */}
                <div className="absolute inset-0 pointer-events-none z-0 opacity-[0.03]">
                    <div className="w-full h-full max-w-[1400px] mx-auto grid grid-cols-4 md:grid-cols-12 gap-4 px-4 md:px-[8%]">
                        {Array.from({ length: 12 }).map((_, i) => (
                            <div key={i} className="hidden md:block h-full border-r border-foreground" />
                        ))}
                    </div>
                </div>

                <div className="w-full max-w-none px-4 md:px-[8%] relative z-10">
                    <div className="max-w-5xl mb-24 md:mb-40">
                        <motion.div
                            initial={{ opacity: 0, y: 40 }}
                            whileInView={{ opacity: 1, y: 0 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ duration: 1.2, ease: "easeOut" }}
                        >
                            <div className="flex items-center gap-4 mb-8">
                               <div className="w-12 h-[1px] bg-accent" />
                               <span className="text-[10px] font-sans font-bold tracking-[0.8em] uppercase text-accent">Visionary Technology</span>
                            </div>
                            
                            <h2 className="text-5xl sm:text-6xl md:text-8xl lg:text-9xl font-serif font-light text-foreground leading-[0.9] tracking-tighter mb-10 md:mb-16">
                                Beyond <br />
                                <span className="italic text-muted-foreground/80">Physicality.</span>
                            </h2>
                            <p className="text-lg md:text-2xl lg:text-3xl text-foreground/60 leading-relaxed font-sans font-light max-w-3xl">
                                We combine traditional craftsmanship with advanced technology to ensure 
                                each stone is perfectly integrated into your vision. Experience precision at every step.
                            </p>
                        </motion.div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 lg:gap-16">
                        {[
                            {
                                icon: Eye,
                                title: "Digital Twin Mapping",
                                desc: "Every slab in our gallery is 8K laser-scanned to create a pixel-perfect digital twin. Seamlessly drop our textures into your CAD environment."
                            },
                            {
                                icon: Cpu,
                                title: "Interactive VR",
                                desc: "Walk through your residence in profound virtual reality. Experience the granular detail and precise light reflection of our hand-picked stones."
                            },
                            {
                                icon: Zap,
                                title: "Structural Analysis",
                                desc: "Employing ultrasonic mapping, we reveal internal mineral density, guaranteeing structural longevity designed to endure for centuries."
                            },
                            {
                                icon: ShieldCheck,
                                title: "Quality Guarantee",
                                desc: "Each stone is accompanied by a certificate of origin and quality, documenting its provenance and sustainable sourcing trail."
                            }
                        ].map((tech, i) => (
                            <motion.div
                                key={i}
                                initial={{ opacity: 0, scale: 0.98, y: 30 }}
                                whileInView={{ opacity: 1, scale: 1, y: 0 }}
                                viewport={{ once: true, margin: "-50px" }}
                                transition={{ duration: 1, delay: i * 0.15, ease: "easeOut" }}
                                className="group p-10 md:p-16 bg-foreground/[0.02] border border-border/40 hover:bg-foreground/[0.04] hover:border-accent/40 transition-all duration-700 relative overflow-hidden"
                            >
                                {/* Hover Gradient Effect */}
                                <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:bg-accent/10 transition-colors duration-700 pointer-events-none" />
                                
                                <tech.icon className="w-10 h-10 md:w-12 md:h-12 text-accent mb-10 stroke-[1px] group-hover:scale-110 group-hover:text-foreground transition-all duration-500" />
                                <h3 className="text-2xl md:text-3xl lg:text-4xl font-serif font-light text-foreground mb-6 tracking-tight">{tech.title}</h3>
                                <p className="text-base md:text-lg text-foreground/60 leading-relaxed font-sans font-light">{tech.desc}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>
        </PageLayout>
        </>
    );
};

export default OurProcess;
