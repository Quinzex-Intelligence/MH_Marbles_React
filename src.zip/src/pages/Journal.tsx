import SEO from '@/components/SEO';
import { PageLayout } from '@/components/PageLayout';
import { Reviews } from '@/components/Reviews';
import { motion } from 'framer-motion';

const JournalPage = () => {
    return (
        <>
            <SEO 
                title="The Journal: Architectural Insights" 
                description="Read about our latest journeys to Italian quarries, new showroom openings, and architectural transformations."
            />
            <PageLayout
            title="The Journal."
            subtitle="Voices of Vision"
        >
            <div className="space-y-0">
                <Reviews />
                
                <section className="bg-foreground text-background py-32 md:py-48 relative overflow-hidden group">
                    <div className="absolute inset-0 opacity-10 blur-2xl group-hover:blur-3xl transition-all duration-[3s] bg-accent mix-blend-screen scale-150 rounded-full w-2/3 h-2/3 -bottom-1/4 -left-1/4 pointer-events-none" />
                    
                    <div className="w-full max-w-none px-4 md:px-[8%] relative z-10 text-center">
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95, y: 30 }}
                            whileInView={{ opacity: 1, scale: 1, y: 0 }}
                            viewport={{ once: true, margin: "-100px" }}
                            transition={{ duration: 1.5, ease: "easeOut" }}
                            className="max-w-4xl mx-auto"
                        >
                            <span className="text-[10px] font-sans font-bold tracking-[0.8em] uppercase text-accent mb-10 block">Be Part of the Story</span>
                            
                            <h3 className="text-4xl sm:text-5xl md:text-7xl lg:text-8xl font-serif font-light leading-[0.9] tracking-tighter mb-10 md:mb-16">
                                Submit Your <br />
                                <span className="italic text-muted-foreground/80">Narrative.</span>
                            </h3>
                            
                            <p className="text-base md:text-2xl font-sans font-light text-background/60 leading-relaxed mb-16 max-w-2xl mx-auto">
                                We are continually seeking to share the extraordinary ways our stones have transformed architectural spaces. Contact us to have your project featured in our Journal.
                            </p>
 
                            <a href="/contact" className="inline-flex items-center justify-center border border-accent hover:bg-accent hover:text-white h-16 px-12 text-[10px] font-sans font-bold uppercase tracking-[0.5em] transition-all duration-700">
                                Contact Us
                            </a>
                        </motion.div>
                    </div>
                </section>
            </div>
        </PageLayout>
        </>
    );
};

export default JournalPage;
