import SEO from '@/components/SEO';
import { PageLayout } from '@/components/PageLayout';
import { WhyUs } from '@/components/WhyUs';
import { motion } from 'framer-motion';

const HeritagePage = () => {
    return (
        <>
            <SEO 
                title="The Heritage: A Legacy of Craft" 
                description="Discover the foundations of MH Marbles. Since 1980, sourcing the earth's most spectacular geological formations to elevate human environments."
            />
            <PageLayout
            title="The Heritage."
            subtitle="Our Heritage"
        >
            <div className="space-y-0">
                <WhyUs />
                
                <section className="py-24 md:py-48 bg-foreground text-background relative overflow-hidden z-10 border-t border-background/10">
                    <div className="w-full max-w-none px-4 md:px-[8%]">
                        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 md:gap-24 items-center">
                            
                            {/* Visual Spread */}
                            <motion.div 
                                initial={{ opacity: 0, scale: 0.95 }}
                                whileInView={{ opacity: 1, scale: 1 }}
                                viewport={{ once: true, margin: "-100px" }}
                                transition={{ duration: 1.5, ease: "easeOut" }}
                                className="lg:col-span-7 relative group"
                            >
                                <div className="aspect-[4/5] md:aspect-[16/9] lg:aspect-[4/5] bg-background/5 overflow-hidden ring-1 ring-white/10 relative z-10">
                                    <img 
                                        src="https://images.unsplash.com/photo-1600566752355-35792bedcfea?auto=format&fit=crop&q=80&w=1200" 
                                        alt="Master Craftsmanship" 
                                        className="w-full h-full object-cover opacity-80 grayscale-[30%] contrast-125 group-hover:scale-105 transition-transform duration-[2s] ease-out" 
                                    />
                                    {/* High Contrast Overlay */}
                                    <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-transparent to-transparent pointer-events-none" />
                                </div>
                                <div className="absolute -bottom-10 -right-10 md:-bottom-16 md:-right-16 bg-accent p-8 md:p-12 z-20 shadow-2xl hidden md:block">
                                    <span className="text-[10px] font-sans font-bold uppercase tracking-[0.5em] text-foreground">Est. 1980</span>
                                </div>
                            </motion.div>

                            {/* Narrative Focus */}
                            <motion.div 
                                initial={{ opacity: 0, x: 50 }}
                                whileInView={{ opacity: 1, x: 0 }}
                                viewport={{ once: true, margin: "-100px" }}
                                transition={{ duration: 1.2, ease: "easeOut", delay: 0.2 }}
                                className="lg:col-span-5 space-y-10 md:space-y-16 relative z-20"
                            >
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-[1px] bg-accent" />
                                    <span className="text-[10px] font-sans font-bold tracking-[0.8em] uppercase text-accent">The Foundation</span>
                                </div>
                                
                                <h3 className="text-5xl sm:text-6xl md:text-8xl font-serif font-light leading-[0.9] tracking-tighter">
                                    Generations <br />
                                    <span className="italic text-muted-foreground/80">of Craft.</span>
                                </h3>
                                
                                <div className="space-y-8 text-base md:text-xl font-sans font-light text-background/60 leading-relaxed max-w-lg relative">
                                    {/* Subtle quotation mark background */}
                                    <span className="absolute -top-16 -left-8 text-8xl font-serif text-accent/10 leading-none pointer-events-none">"</span>
                                    <p>
                                        Founded in 1980 by master stone-carvers, MH Marble has evolved into
                                        an international destination for architectural visionaries.
                                    </p>
                                    <p>
                                        Our commitment remains resolute: sourcing the earth's most spectacular geological formations to elevate human environments into timeless sanctuaries.
                                    </p>
                                </div>
                            </motion.div>
                            
                        </div>
                    </div>
                </section>
            </div>
        </PageLayout>
        </>
    );
};

export default HeritagePage;
