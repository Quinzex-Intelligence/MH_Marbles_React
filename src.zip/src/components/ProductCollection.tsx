import { useRef, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Tile } from '@/data/tiles';
import { useGallery } from '@/contexts/GalleryContext';
import { cn } from '@/lib/utils';
import { SlabImage } from './SlabImage';

gsap.registerPlugin(ScrollTrigger);

export function ProductCollection() {
  const sectionRef = useRef<HTMLElement>(null);
  const { tiles } = useGallery();
  const [selectedSpace, setSelectedSpace] = useState<string>('All');

  const spaces = ['All', 'Kitchen', 'Living Room', 'Bathroom', 'Outdoor', 'Commercial'];
  
  const filteredTiles = selectedSpace === 'All' 
    ? tiles 
    : tiles.filter(t => t.space === selectedSpace || (t.usage && t.usage.includes(selectedSpace)));


  return (
    <section ref={sectionRef} id="collection" className="py-24 md:py-48 bg-[#0C0A08] relative z-10 overflow-hidden">
      {/* Background Architectural Grid - Refined */}
      <div className="absolute inset-0 pointer-events-none z-0 opacity-[0.03]">
        <div className="w-full h-full max-w-[1400px] mx-auto grid grid-cols-4 md:grid-cols-12 gap-4 px-4 md:px-[8%]">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="hidden md:block h-full border-r border-white/20" />
            ))}
        </div>
      </div>

      {/* Decorative side line */}
      <div className="absolute top-0 right-[8%] w-[1px] h-full bg-white/[0.03] pointer-events-none" />

      <div className="w-full max-w-none px-4 md:px-[8%] relative z-10 mb-20 md:mb-40">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="max-w-5xl"
        >
          <div className="flex items-center gap-4 mb-10">
             <div className="w-16 h-[1px] bg-[#C8A96E]" />
             <span className="text-[9px] font-sans font-bold tracking-[0.9em] uppercase text-[#C8A96E]">THE COLLECTION</span>
          </div>
          <h2 className="text-5xl sm:text-7xl md:text-8xl lg:text-[9rem] font-serif font-light text-white leading-[0.85] tracking-tight mb-12">
            Sculptural <br />
            <span className="italic text-white/20">Statements.</span>
          </h2>
          <p className="text-lg md:text-2xl text-white/35 max-w-2xl font-sans font-light leading-relaxed">
            An immersive journey through the earth’s most exquisite formations.
            Each slab is a singular masterpiece, curated for the visionary architect.
          </p>
        </motion.div>

        {/* Space Filtering UI - Refined */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-20 flex flex-wrap gap-x-12 gap-y-8 border-b border-white/5 pb-10"
        >
          {spaces.map((space) => (
            <button
              key={space}
              onClick={() => setSelectedSpace(space)}
              className={cn(
                "text-[9px] font-black uppercase tracking-[0.5em] transition-all duration-500 relative py-2",
                selectedSpace === space ? "text-[#C8A96E]" : "text-white/20 hover:text-white/60"
              )}
            >
              {space}
              {selectedSpace === space && (
                <motion.div 
                  layoutId="spaceTab"
                  className="absolute bottom-0 left-0 w-full h-[1px] bg-[#C8A96E]"
                />
              )}
            </button>
          ))}
        </motion.div>
      </div>

      <div className="flex flex-col gap-32 md:gap-48 lg:gap-64 relative z-10 pt-10">
        <AnimatePresence mode="popLayout">
          {filteredTiles.slice(0, 6).map((tile, index) => (
            <ShowcaseItem key={tile.id} tile={tile} index={index} />
          ))}
        </AnimatePresence>
      </div>
    </section>
  );
}

function ShowcaseItem({ tile, index }: { tile: Tile; index: number }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const bgTextRef = useRef<HTMLDivElement>(null);
  const isEven = index % 2 === 0;

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Parallax for huge background text - much slower
      gsap.to(bgTextRef.current, {
        y: '-15%',
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: true,
        }
      });

      // Image Reveal - elegant rise
      gsap.from(imageRef.current, {
        y: 80,
        opacity: 0,
        scale: 0.98,
        duration: 1.8,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: imageRef.current,
          start: 'top 85%',
        }
      });

      // Text Interaction - staggered fade up
      gsap.from(textRef.current?.children || [], {
        y: 30,
        opacity: 0,
        duration: 1.4,
        stagger: 0.1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: textRef.current,
          start: 'top 80%',
        }
      });
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={containerRef} className="relative w-full max-w-none px-6 md:px-[6%] py-12 md:py-24">
      
      {/* Dynamic Background Element */}
      <div 
         ref={bgTextRef}
         className={cn(
          "absolute -z-10 text-[30vw] sm:text-[25vw] font-serif font-black text-white/[0.015] leading-none pointer-events-none select-none italic top-0 md:top-[-10%]",
          isEven ? "right-[5%]" : "left-[5%]"
         )}
      >
        {String(index + 1).padStart(2, '0')}
      </div>

      <div className={cn(
        "grid grid-cols-1 md:grid-cols-12 gap-12 md:gap-8 items-center",
      )}>
        
        {/* Editorial Image Block */}
        <div className={cn(
          "md:col-span-7 relative group flex justify-center",
          isEven ? "md:order-1 md:justify-start" : "md:order-2 md:justify-end"
        )}>
          <div ref={imageRef} className="relative z-10 w-full max-w-[600px] bg-[#0C0A08] p-2 md:p-4 border border-white/5 shadow-[0_30px_100px_rgba(0,0,0,0.8)] group-hover:border-[#C8A96E]/20 transition-colors duration-1000">
            <div className="overflow-hidden">
               <div className="transform group-hover:scale-105 transition-transform duration-[2s] ease-out">
                 <SlabImage image={tile.image} color={tile.textureColor} name={tile.name} />
               </div>
            </div>
            
            {/* Subtle overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0C0A08]/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000 pointer-events-none" />
            
            {/* Minimalist details tag directly on image container */}
            <div className="absolute bottom-6 md:bottom-10 right-6 md:right-10 bg-[#0C0A08]/80 backdrop-blur-md px-6 py-4 border border-white/10 opacity-0 group-hover:opacity-100 transition-all duration-700 translate-y-4 group-hover:translate-y-0">
               <div className="flex items-center gap-4 text-[8px] font-sans font-black uppercase tracking-[0.4em] text-white/50">
                 <span className="text-[#C8A96E]">{tile.finishes[0]} Finish</span>
                 <span>•</span>
                 <span>{tile.thickness}mm</span>
               </div>
            </div>
          </div>
        </div>

        {/* Narrative Block - Asymmetrically vertically aligned */}
        <div className={cn(
          "md:col-span-5 relative z-20 flex flex-col",
          isEven ? "md:order-2 md:-mt-32 md:pl-8 lg:pl-16" : "md:order-1 md:mt-48 md:items-end md:text-right md:pr-8 lg:pr-16"
        )}>
           <div ref={textRef} className="w-full max-w-[480px]">
              <div className="mb-8 md:mb-12">
                 <div className={cn("flex items-center gap-4 mb-6", !isEven && "justify-end")}>
                   {isEven && <div className="w-8 h-[1px] bg-[#C8A96E]/50" />}
                   <span className="text-[9px] font-sans font-black text-[#C8A96E]/60 uppercase tracking-[0.6em]">Gallery {String(index + 1).padStart(2, '0')}</span>
                   {!isEven && <div className="w-8 h-[1px] bg-[#C8A96E]/50" />}
                 </div>
                 
                 <h3 className="text-5xl sm:text-6xl md:text-7xl lg:text-[5.5rem] font-serif font-light text-white leading-[0.85] tracking-tight">
                   {tile.name}
                 </h3>
              </div>

              <p className="text-base md:text-xl lg:text-2xl text-white/40 leading-relaxed font-serif font-light italic mb-10 md:mb-16">
                "{tile.description}"
              </p>

              <div className="space-y-6">
                 <div className={cn("flex items-center gap-4", !isEven && "justify-end")}>
                    <span className="text-[8px] font-sans font-bold uppercase tracking-[0.4em] text-[#C8A96E]/50 w-24">Origin</span>
                    <span className="text-xs md:text-sm font-serif text-white/80 italic">{tile.origin}</span>
                 </div>
                 <div className="w-full h-[1px] bg-white/5" />
                 <div className={cn("flex items-center gap-4", !isEven && "justify-end")}>
                    <span className="text-[8px] font-sans font-bold uppercase tracking-[0.4em] text-[#C8A96E]/50 w-24">Category</span>
                    <span className="text-xs md:text-sm font-serif text-white/80 italic">{tile.category}</span>
                 </div>
                 <div className="w-full h-[1px] bg-white/5" />
                 
                 <div className={cn("pt-4 flex", !isEven && "justify-end")}>
                    <a href="#contact" className="group inline-flex items-center gap-4 text-[9px] font-black uppercase tracking-[0.4em] text-white/30 hover:text-[#C8A96E] transition-colors duration-500">
                      View Slab Specifications
                      <span className="w-8 h-[1px] bg-white/10 group-hover:w-16 group-hover:bg-[#C8A96E] transition-all duration-500" />
                    </a>
                 </div>
              </div>
           </div>
        </div>

      </div>
    </div>
  );
}

export default ProductCollection;
