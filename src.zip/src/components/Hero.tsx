import { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';

const SLIDES = [
  {
    label: 'Italian Calacatta',
    image: 'https://images.unsplash.com/photo-1618221118493-9cfa1a1c00da?auto=format&fit=crop&q=80&w=1600',
    accent: '#C8A96E',
  },
  {
    label: 'Black Marquina',
    image: 'https://images.unsplash.com/photo-1567225557594-88d73e55f2cb?auto=format&fit=crop&q=80&w=1600',
    accent: '#B89A5E',
  },
  {
    label: 'Emperador Dark',
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?auto=format&fit=crop&q=80&w=1600',
    accent: '#D4AF7A',
  },
];

export function Hero() {
  const [current, setCurrent] = useState(0);
  const [animating, setAnimating] = useState(false);
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimating(true);
      setTimeout(() => {
        setCurrent(prev => (prev + 1) % SLIDES.length);
        setAnimating(false);
      }, 600);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const slide = SLIDES[current];

  return (
    <section
      ref={heroRef}
      className="relative h-screen w-full overflow-hidden bg-[#0C0A08] flex items-stretch"
    >
      {/* ─── LEFT PANEL: Bold Typography ─── */}
      <motion.div
        style={{ opacity }}
        className="relative z-20 flex flex-col justify-between w-full md:w-[52%] px-8 sm:px-14 md:px-20 py-10 pt-28 md:pt-32"
      >
        {/* Thin top rule */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 2, ease: [0.16, 1, 0.3, 1], delay: 0.3 }}
          className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#C8A96E]/60 to-transparent origin-left"
        />

        <div>
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="flex items-center gap-4 mb-10 md:mb-14"
          >
            <div className="w-8 h-[1px] bg-[#C8A96E]" />
            <span className="text-[9px] font-sans font-bold tracking-[0.9em] uppercase text-[#C8A96E]">
              Est. 1980 · Hyderabad
            </span>
          </motion.div>

          {/* Main Heading */}
          <div className="overflow-hidden mb-4">
            <motion.h1
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.5 }}
              className="text-[4rem] sm:text-[5.5rem] md:text-[6rem] lg:text-[8rem] font-serif font-light text-white leading-[0.82] tracking-[-0.03em]"
            >
              Stone
            </motion.h1>
          </div>
          <div className="overflow-hidden mb-4">
            <motion.h1
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.7 }}
              className="text-[4rem] sm:text-[5.5rem] md:text-[6rem] lg:text-[8rem] font-serif font-light leading-[0.82] tracking-[-0.03em]"
              style={{ color: slide.accent, transition: 'color 0.8s ease' }}
            >
              Refined
            </motion.h1>
          </div>
          <div className="overflow-hidden">
            <motion.h1
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.9 }}
              className="text-[4rem] sm:text-[5.5rem] md:text-[6rem] lg:text-[8rem] font-serif font-light italic text-white/30 leading-[0.82] tracking-[-0.03em]"
            >
              Forever.
            </motion.h1>
          </div>
        </div>

        {/* Bottom bar */}
        <div>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.4 }}
            className="text-white/40 text-base md:text-lg font-sans font-light leading-relaxed max-w-sm mb-10"
          >
            Curators of the earth's most exquisite architectural statements.
            Italian marble & exotic stones for the discerning visionary.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.6 }}
            className="flex items-center gap-6"
          >
            <a
              href="/collection"
              className="group relative inline-flex items-center gap-4 text-[10px] font-sans font-black uppercase tracking-[0.5em] text-white/80 hover:text-[#C8A96E] transition-colors duration-500"
            >
              <span
                className="block w-14 h-[1px] transition-all duration-500 group-hover:w-20"
                style={{ background: slide.accent }}
              />
              Explore Collection
            </a>
            <div className="w-[1px] h-6 bg-white/10" />
            <a
              href="#contact"
              className="text-[10px] font-sans font-bold uppercase tracking-[0.5em] text-white/20 hover:text-white/60 transition-colors duration-500"
            >
              Contact
            </a>
          </motion.div>

          {/* Slide indicators */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 2 }}
            className="flex items-center gap-3 mt-12"
          >
            {SLIDES.map((s, i) => (
              <button
                key={i}
                onClick={() => { setAnimating(true); setTimeout(() => { setCurrent(i); setAnimating(false); }, 300); }}
                className="flex items-center gap-2 group"
              >
                <div
                  className="h-[1px] transition-all duration-700"
                  style={{
                    width: i === current ? '32px' : '12px',
                    background: i === current ? slide.accent : 'rgba(255,255,255,0.15)',
                  }}
                />
                <span
                  className="text-[8px] font-bold uppercase tracking-widest transition-colors duration-300"
                  style={{ color: i === current ? slide.accent : 'rgba(255,255,255,0.2)' }}
                >
                  {String(i + 1).padStart(2, '0')}
                </span>
              </button>
            ))}
          </motion.div>
        </div>
      </motion.div>

      {/* ─── RIGHT PANEL: Image ─── */}
      <motion.div
        style={{ y }}
        className="absolute right-0 top-0 bottom-0 w-full md:w-[56%] overflow-hidden"
      >
        {/* Diagonal mask on left edge for desktop */}
        <div className="absolute inset-0 z-10 hidden md:block" style={{
          background: 'linear-gradient(105deg, #0C0A08 0%, #0C0A08 28%, transparent 52%)',
        }} />
        {/* Dark overlay */}
        <div className="absolute inset-0 z-[5] bg-gradient-to-b from-[#0C0A08]/70 via-[#0C0A08]/20 to-[#0C0A08]/80" />
        <div className="absolute inset-0 z-[5] bg-gradient-to-r from-[#0C0A08] via-transparent to-transparent md:hidden" />

        {/* Image */}
        <motion.img
          key={current}
          src={slide.image}
          alt={slide.label}
          initial={{ opacity: 0, scale: 1.08 }}
          animate={{ opacity: animating ? 0 : 1, scale: animating ? 1.08 : 1.03 }}
          transition={{ opacity: { duration: 0.8 }, scale: { duration: 8, ease: 'linear' } }}
          className="w-full h-full object-cover"
        />

        {/* Slide name tag */}
        <motion.div
          key={`tag-${current}`}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: animating ? 0 : 1, y: animating ? 10 : 0 }}
          transition={{ duration: 0.6 }}
          className="absolute bottom-12 right-8 md:right-12 z-20 text-right"
        >
          <p className="text-[9px] font-sans font-bold uppercase tracking-[0.6em] text-white/30 mb-2">
            Featured Stone
          </p>
          <p className="font-serif text-xl md:text-2xl text-white/80 italic">{slide.label}</p>
        </motion.div>

        {/* Corner ornament */}
        <div className="absolute top-8 right-8 z-20 opacity-40">
          <div className="w-12 h-12 border-t border-r border-[#C8A96E]/60" />
        </div>
      </motion.div>

      {/* ─── Vertical scroll hint ─── */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.5, duration: 1 }}
        className="absolute bottom-10 left-8 sm:left-14 md:left-20 z-30 flex items-center gap-4"
      >
        <div className="w-[1px] h-16 relative overflow-hidden bg-white/10">
          <motion.div
            className="absolute top-0 w-full"
            style={{ background: `linear-gradient(to bottom, ${slide.accent}, transparent)`, height: '50%' }}
            animate={{ y: ['-100%', '200%'] }}
            transition={{ repeat: Infinity, duration: 1.8, ease: 'linear' }}
          />
        </div>
        <span className="text-[8px] font-bold uppercase tracking-[0.7em] text-white/20 rotate-0">Scroll</span>
      </motion.div>
    </section>
  );
}

export default Hero;
