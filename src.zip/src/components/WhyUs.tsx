import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useGallery } from '@/contexts/GalleryContext';

const PILLARS = [
  {
    num: '01',
    title: 'Ancient Sourcing',
    body: 'Every slab is hand-selected from quarries that have supplied stone to civilization\'s greatest monuments—Carrara, Estremoz, Marquina.',
    icon: '◈',
  },
  {
    num: '02',
    title: '45 Years of Craft',
    body: 'Four decades of mastering the art of stone curation, building lasting relationships with the world\'s finest quarry masters.',
    icon: '◇',
  },
  {
    num: '03',
    title: 'Singular Slabs',
    body: 'No two slabs are alike. We celebrate each stone\'s unique veining, its billion-year biography etched in mineral.',
    icon: '⬡',
  },
  {
    num: '04',
    title: 'Visionary Spaces',
    body: 'From private residences to landmark commercial projects, our stones have defined India\'s most celebrated interiors.',
    icon: '⬟',
  },
];

const STATS = [
  { value: '45+', label: 'Years of Legacy' },
  { value: '500+', label: 'Unique Textures' },
  { value: '2,000+', label: 'Projects Realized' },
  { value: '12', label: 'Countries Sourced' },
];

export function WhyUs() {
  const { brands } = useGallery();
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({ target: sectionRef, offset: ['start end', 'end start'] });
  const bgY = useTransform(scrollYProgress, [0, 1], ['0%', '15%']);

  return (
    <section
      ref={sectionRef}
      id="why-us"
      className="relative overflow-hidden bg-[#0C0A08]"
    >
      {/* ── PART 1: Stats strip ───────────────────────────── */}
      <div className="relative border-y border-white/5 py-12 md:py-16 overflow-hidden">
        {/* animated bg stripe */}
        <motion.div
          style={{ y: bgY }}
          className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=2000')] bg-cover bg-center opacity-[0.04] scale-110"
        />
        <div className="relative z-10 w-full px-4 md:px-[8%] grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-0 divide-x-0 md:divide-x md:divide-white/5">
          {STATS.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: i * 0.1 }}
              className="flex flex-col items-center text-center px-6 py-2"
            >
              <span className="font-serif text-4xl md:text-6xl font-light text-[#C8A96E] tracking-tight italic">
                {s.value}
              </span>
              <span className="mt-3 text-[9px] font-sans font-bold uppercase tracking-[0.5em] text-white/20">
                {s.label}
              </span>
            </motion.div>
          ))}
        </div>
      </div>

      {/* ── PART 2: Header + Pillars ─────────────────────── */}
      <div className="w-full px-4 md:px-[8%] pt-24 md:pt-36 pb-24 md:pb-36">
        <div className="flex flex-col lg:flex-row gap-16 md:gap-24">

          {/* Sticky label column */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1.2 }}
            className="lg:w-[38%] lg:sticky lg:top-32 lg:self-start"
          >
            <div className="flex items-center gap-4 mb-8">
              <div className="w-10 h-[1px] bg-[#C8A96E]" />
              <span className="text-[9px] font-sans font-bold tracking-[0.9em] uppercase text-[#C8A96E]">
                Architecture & Soul
              </span>
            </div>

            <h2 className="font-serif font-light text-white text-5xl md:text-7xl leading-[0.88] tracking-[-0.02em] mb-8">
              Why the<br />
              <span className="italic text-white/30">World Chooses</span><br />
              MH Marble.
            </h2>

            <p className="text-white/40 font-sans font-light text-base md:text-lg leading-relaxed max-w-sm">
              For nearly half a century, we have curated a sanctuary of the earth's most exquisite stones — not merely surfaces, but enduring statements.
            </p>

            {/* Decorative image */}
            <div className="relative mt-12 w-full max-w-xs aspect-[4/5] overflow-hidden hidden lg:block">
              <img
                src="https://images.unsplash.com/photo-1618221118493-9cfa1a1c00da?auto=format&fit=crop&q=80&w=800"
                alt="Marble detail"
                className="w-full h-full object-cover opacity-50 grayscale-[30%] scale-110 hover:scale-100 transition-transform duration-[3s]"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0C0A08] via-transparent to-transparent" />
              <div className="absolute inset-0 border border-white/5 m-4" />
              {/* Tag */}
              <div className="absolute bottom-6 left-6">
                <p className="text-[8px] font-bold uppercase tracking-[0.5em] text-[#C8A96E]/60">
                  Calacatta Gold
                </p>
              </div>
            </div>
          </motion.div>

          {/* Pillars */}
          <div className="lg:w-[62%] flex flex-col gap-0">
            {PILLARS.map((p, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: '-60px' }}
                transition={{ duration: 1, delay: i * 0.1 }}
                className="group flex items-start gap-6 md:gap-10 py-10 md:py-14 border-t border-white/5 hover:border-[#C8A96E]/20 transition-all duration-700 cursor-default"
              >
                <div className="flex-shrink-0 w-10 md:w-16 text-right mt-1">
                  <span className="text-[9px] font-bold font-sans text-white/15 uppercase tracking-[0.4em]">{p.num}</span>
                </div>

                <div className="text-3xl md:text-4xl text-[#C8A96E]/30 group-hover:text-[#C8A96E]/60 transition-colors duration-500 flex-shrink-0 mt-1">
                  {p.icon}
                </div>

                <div className="flex-1">
                  <h3 className="font-serif text-2xl md:text-4xl font-light text-white tracking-tight mb-4 group-hover:text-[#C8A96E] transition-colors duration-700">
                    {p.title}
                  </h3>
                  <p className="text-white/35 font-sans font-light text-sm md:text-base leading-relaxed max-w-md group-hover:text-white/55 transition-colors duration-500">
                    {p.body}
                  </p>
                </div>

                {/* Arrow */}
                <div className="flex-shrink-0 mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <div className="w-8 h-[1px] bg-[#C8A96E]/40 relative">
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 border-t border-r border-[#C8A96E]/40 w-2 h-2 rotate-45 -translate-x-[1px]" />
                  </div>
                </div>
              </motion.div>
            ))}
            <div className="border-t border-white/5" />
          </div>
        </div>
      </div>

      {/* ── PART 3: Brand partners ───────────────────────── */}
      {brands && brands.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="border-t border-white/5 py-16 md:py-20 px-4 md:px-[8%]"
        >
          <p className="text-[9px] font-sans font-bold uppercase tracking-[0.7em] text-[#C8A96E]/30 text-center mb-12">
            Distinguished Partners
          </p>
          <div className="flex flex-wrap justify-center gap-x-10 md:gap-x-20 gap-y-8 items-center">
            {brands.map(brand => (
              <div key={brand.id} className="group flex flex-col items-center gap-3 opacity-25 hover:opacity-80 transition-opacity duration-700">
                {brand.image && (
                  <img src={brand.image} alt={brand.name} className="h-7 md:h-9 object-contain grayscale" />
                )}
                <span className="text-xs md:text-base font-serif font-light tracking-[0.4em] uppercase text-white/70 group-hover:text-[#C8A96E] transition-colors duration-500 text-center">
                  {brand.name}
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </section>
  );
}

export default WhyUs;
