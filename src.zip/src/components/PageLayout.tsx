import React from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { motion } from 'framer-motion';

interface PageLayoutProps {
    children: React.ReactNode;
    title: string;
    subtitle: string;
}

export function PageLayout({ children, title, subtitle }: PageLayoutProps) {
    return (
        <div className="min-h-screen bg-background w-full overflow-x-hidden">
            <Header />
            <main className="pt-28 pb-16 md:pt-36 md:pb-24 lg:pt-48 lg:pb-32 w-full">
                {/* Header Section remains padded for architectural alignment */}
                <div className="w-full px-6 md:px-[8%] relative z-10">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 1 }}
                        className="mb-12 md:mb-20 lg:mb-32 max-w-5xl"
                    >
                        <div className="flex items-center gap-4 mb-6">
                           <div className="w-12 h-[1px] bg-accent" />
                           <span className="text-[10px] font-sans font-bold tracking-[0.6em] uppercase text-accent block">{subtitle}</span>
                        </div>
                        <h1 className="text-6xl sm:text-7xl md:text-[8rem] lg:text-[10rem] font-serif font-light text-foreground leading-[0.85] tracking-tighter italic">
                            {title.split(' ')[0]} <br />
                            <span className="not-italic font-medium text-foreground">{title.split(' ').slice(1).join(' ')}</span>
                        </h1>
                    </motion.div>
                </div>

                <div className="w-full">
                   {children}
                </div>
            </main>
            <Footer />
        </div>
    );
}
